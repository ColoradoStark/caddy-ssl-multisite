<html>
<head>
    <title>PHP Demo</title>
    <style type="text/css">
        #wrap {
            width: 900px;
            margin: 0 auto;
        }
    </style>
</head>
<body id="wrap">
    
    <?php 
        // Test if PHP works
        echo '<h1><p>If you see this message PHP is working</p></h1>';
    ?>



</body>
</html>